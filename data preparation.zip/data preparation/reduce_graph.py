import numpy as np

def reduce_graph(F, A):
    """drop nodes and adjacent edges if always equal 0"""
    F_prime = F[:, :, 0]        # only node feature at index 0 i.e. human presence
    heatmap = np.sum(F_prime, axis=0)

    # need list with all idx which are never visited by any human during the entire 2h simulation
    idx = np.where(heatmap == 0)
    # np.save("data/input_matrices/idx.npy", idx)

    # delete from A and F if in list idx
    A = np.delete(A, idx, 0)
    A = np.delete(A, idx, 1)
    F = np.delete(F, idx, axis=1)

    return F, A, idx


def back_to_occupancy_grid(F, idx):
    """add back the removed nodes"""
    F_prime = F[:, :, 0]
    full_F = np.insert(F_prime, idx[0] - np.arange(len(idx[0])), 0, axis=1)

    return full_F

if __name__ == "__main__":
    F = np.load("...")
    A = np.load("...")

    F, A, idx = reduce_graph(F, A)
    F = back_to_occupancy_grid(F, idx)

    # np.save("data/input_matrices/test_A.npy", A)
    # np.save("data/input_matrices/test_F.npy", F)

