import pickle
import numpy as np

from data_loader import HumanPresenceDataLoader
from generate_input_matrices import getfiles, feature_matrix, adj_matrix
from reduce_graph import reduce_graph


if __name__ == "__main__":
    name = "..."

    ################### Feature Matrix ###################
    # extract data and F feature matrix
    path_logs = "../data"
    sim_folder_names = ["simulation2-100p-100cm"]       # simulations to use in dataset

    files = getfiles(path_logs, sim_folder_names)
    F = feature_matrix(files)
    print(F.shape)
    np.save("input_matrices/FeatureMatrix_" + name + ".npy", F)

    ################### Adjacency Matrix ###################
    # create adjacency matrix
    N_nodes = len(F[0])
    A = adj_matrix(N_nodes)
    print(A.shape)

    ################### Reduce Graph ###################
    # reduce A and F
    F, A, idx = reduce_graph(F, A)
    # np.save("input_matrices/Adj_Matrix" + name + ".npy", A)
    print(F.shape)
    print(A.shape)

    np.save("input_matrices/FeatureMatrix_Reduced_" + name + ".npy", F)
    np.save("input_matrices/Adj_Matrix_Reduced_" + name + ".npy", A)
    np.save("input_matrices/idx_" + name + ".npy", idx)


    ################### Load Data for Model ###################
    # use dataloader to load dataset into correct format
    loader = HumanPresenceDataLoader(A, F, normalize=True)
    dataset = loader.get_dataset(num_t_in=5, num_t_out=40)
    print(next(iter(dataset[0])))

    pickle.dump(dataset, open("dataset_norm_" + name + ".p", "wb"))

