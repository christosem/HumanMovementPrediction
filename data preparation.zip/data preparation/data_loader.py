import numpy as np
import torch
from torch_geometric.utils import dense_to_sparse
from torch_geometric_temporal import StaticGraphTemporalSignal
import pickle

class HumanPresenceDataLoader():
    """
    This class transforms the adjacency and feature matrix to a StaticGraphTemporalSignal object which matches the
    inputs and targets based on the specified num_t_in and num_t_out. A large part of the code is based upon the
    dataloaders of the torch geometric temporal library.
    """
    def __init__(self, A, F, normalize: bool = False):
        self.A = A      # adjacency matrix
        self.X = F      # feature matrix
        self.norm = normalize

    def data_transformations(self):
        self.X = self.X.transpose((1, 2, 0))    # reshape feature matrix

        if self.norm == True:       # apply z-score normalization if normalization set to true
            self.X = self.normalize_zscore(self.X)

        # convert to torch tensor
        self.A = torch.from_numpy(self.A)
        self.X = torch.from_numpy(self.X)

    def normalize_zscore(self, X):
        self.means = np.mean(X, axis=(0, 2))     # calculate the mean of all features
        X = X - self.means.reshape(1, -1, 1)     # subtract the mean
        self.stds = np.std(X, axis=(0, 2))       # calculate the st dev of all features
        X = X / self.stds.reshape(1, -1, 1)      # divide by the st devs

        return X

    def get_edges_and_weights(self):
        edge_indices, values = dense_to_sparse(self.A)      # create sparse adjacency matrix
        edge_indices = edge_indices.numpy()                 # from torch to numpy array
        values = values.numpy()                             # from torch to numpy array
        self.edges = edge_indices
        self.edge_weights = values

    def get_features_and_target(self, num_t_in:int, num_t_out:int):
        # create the sequences of input data and store as a list of tuples
        # first item in a tuple is the first index of a sequences, the second item the last of the sequence
        indices = [(i, i + (num_t_in + num_t_out)) for i in range(self.X.shape[2] - (num_t_in + num_t_out) + 1)]

        # Generate observations
        features, target = [], []
        for i, j in indices:        # split observations into inputs(features) and targets
            features.append((self.X[:, :, i: i + num_t_in]).numpy())
            target.append((self.X[:, 0, i + num_t_in: j]).numpy())

        self.features = features
        self.targets = target


    def get_dataset(self, num_t_in, num_t_out):
        self.data_transformations()
        self.get_edges_and_weights()
        self.get_features_and_target(num_t_in, num_t_out)

        # load to StaticGraphTemporalSignal object
        dataset = StaticGraphTemporalSignal(self.edges, self.edge_weights, self.features, self.targets)

        if self.norm == True:
            return [dataset, self.means, self.stds]
        else:
            return [dataset, "", ""]

if __name__ == "__main__":
    F = np.load("...")
    A = np.load("...")

    loader = HumanPresenceDataLoader(A, F, normalize=True)
    dataset = loader.get_dataset(num_t_in=5, num_t_out=40)
    print(next(iter(dataset[0])))

    # pickle.dump(dataset, open("data/input_matrices/test_data_for_size.p", "wb"))





