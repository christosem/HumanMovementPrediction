import numpy as np
import os

def getfiles(path, sim):
    """retrieves the file paths of the input data"""

    folder_names = []
    for entry_name in os.listdir(path):
        entry_path = os.path.join(path, entry_name)
        if os.path.isdir(entry_path):
            folder_names.append(entry_name)

    filepaths = []
    for folder in folder_names:
        if folder in sim:
            step = 0
            for file in os.scandir(path + "/" + folder):
                if file.is_file() and file.path[-4:] == ".txt":
                    step += 1
                    filepaths.append(file.path)

    return filepaths


def load_features(f):
    """Loads txt files, extracts all the node features into 1 numpy array"""

    # delete hashtag from file, otherwise will stop reading after #
    delete_hashtag(f)

    # load txt data into numpy array
    d = np.genfromtxt(f, delimiter=[1, 20], dtype=[("f0", np.uint8), ("f1", object)])
    x = d["f1"].astype("U")

    # extract all contextual node features
    w = np.where(np.char.find(x, "Wall") > 0, 1, 0)
    c = np.where(np.char.find(x, "coffee") > 0, 1, 0)
    ws = np.where(np.char.find(x, "WS") > 0, 1, 0)

    # concatenate into 1 array
    # first column is human presence, second wall, third coffee, fourth workstation
    d = np.stack((d["f0"], w), axis=1)
    d = np.concatenate((d, c[:, None]), axis=1)
    d = np.concatenate((d, ws[:, None]), axis=1)

    return d

def delete_hashtag(f):
    """removes all # from an input file"""
    # open file as binary
    with open(f, "rb") as input_file:
        s = input_file.read()
        input_file.close()

        # replace # with nothing
        s = s.replace(b"#", b"")

    # save changed file
    with open(f, "wb") as output_file:
        output_file.write(s)

def feature_matrix(files: list):
    """iterate over all input files and store them into 1 feature matrix"""

    f0 = load_features(files[0]).astype('uint8')
    f1 = load_features(files[1]).astype('uint8')
    features = np.stack((f0, f1))
    for f in files[2:]:
        print(f)
        d = load_features(f).astype('uint8')
        features = np.vstack((features, d[None, :, :]))
    print(features.shape)
    return features

def adj_matrix(N_Nodes: int):
    """
    creates the adjacency matrix as defined in the methodology
    in GENERAL connect a node n to itself and its first degree neighbours
    but some exception! --> indicated in the comments below (when those do not connections do not exist)

    only works if grid is a square matrix of NxN
    only correct if adjacency matrix is symmetric --> undirected graph
    """

    dim = int(np.sqrt(N_Nodes))
    adj_mat = np.zeros((N_Nodes, N_Nodes), dtype="uint8")

    for n in range(N_Nodes):
        adj_mat[n, n] = 1   # connect each node to itself

        # right
        if not (n > (N_Nodes-dim-1)):     # if at last column, no connection to the right
            adj_mat[n, n+dim] = 1

        # below
        if not (n % dim == (dim-1)):     # if at bottom row, no connection to next node below
            adj_mat[n, n + 1] = 1

        # diagonal right below
        if not (n > (N_Nodes-dim-1)) | (n % dim == (dim-1)):      # if at the last column or at the bottom row, no connection to the diagonal right below
            adj_mat[n, n+dim+1] = 1

        # diagonal right up
        if not (n == 0) | (n % dim == 0) | (n > (N_Nodes-dim-1)):       # if at top row or at the last column, no diagonal connection upper right
            adj_mat[n, n+dim-1] = 1

    # as the edges are undirected mirror the upper triangle to the lower triangle
    adj_mat = np.triu(adj_mat) + np.tril(adj_mat.T, -1)

    return adj_mat


if __name__ == "__main__":
    path = "../data"
    files = getfiles(path)

    F = feature_matrix(files)
    print(F.shape)
    N_nodes = len(F[0])
    A = adj_matrix(N_nodes)

    print(F.shape)
    print(A.shape)


